from django import forms
from .models import Contacts


class AddForms(forms.Form):

    class Meta:
        model = Contacts
        fields = ('name', 'relation', 'phone', 'email')