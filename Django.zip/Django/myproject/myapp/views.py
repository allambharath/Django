from django.shortcuts import render
from .forms import AddForms
from .models import Contacts
from django.http import HttpResponseRedirect


def show(request):
    contact_list = Contacts.objects.all()
    return render(request, 'show.html', {'contacts': contact_list})


def new(request):
    return render(request, 'new.html')


def add(request):
    if request.method == 'POST':
        django_form = AddForms(request.POST)
        if django_form.is_valid():
            new_member_name = django_form.data.get("name")
            new_member_relation = django_form.data.get("relation")
            new_member_phone = django_form.data.get("phone")
            new_member_email = django_form.data.get("email")

            Contacts.objects.create(
                name = new_member_name,
                relation = new_member_relation,
                phone = new_member_phone,
                email = new_member_email,
            )
    return render(request, 'add.html')
