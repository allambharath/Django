from django.conf.urls import include, url
from django.contrib import admin
from django.urls import path
from myapp import views

urlpatterns = [
    path('', views.show),
    path('new', views.new, name='new'),
    path('add', views.add, name='add'),
]