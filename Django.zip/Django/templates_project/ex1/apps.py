from django.apps import AppConfig


class Ex1Config(AppConfig):
    name = 'ex1'
