from django.contrib import admin
from .models import Signup_Form

# Register your models here.
admin.site.register(Signup_Form)