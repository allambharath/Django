from django.urls import path
from first import views

urlpatterns = [
    path('', views.home, name='home'),
    path('result', views.result, name='result')
]